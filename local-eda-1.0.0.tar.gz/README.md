# local.eda

Collection custom per Event-Driven Ansible.

## Event source plugins

- `local.eda.controller_jobs` — polling sull'API `/api/controller/v2/workflow_jobs/`
  dell'Automation Controller; emette un evento `controller_job` per ogni job
  concluso (successful/failed) dei template osservati, con dedup sugli ID.

### Uso nella rulebook

```yaml
sources:
  - name: Polling workflow jobs del Controller
    local.eda.controller_jobs:
      controller_host: "{{ controller_host }}"
      token: "{{ controller_token }}"
      watch_templates:
        - WF-1
        - WF-2
      interval: 15
      verify_ssl: true
      statuses:
        - successful
        - failed
```
